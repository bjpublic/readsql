SELECT [VendorID], COUNT([VendorID]) AS COUNTER01 FROM [Purchasing].[PurchaseOrderHeader] GROUP BY [VendorID]

SELECT [VendorID], COUNT([VendorID]) AS COUNTER01 FROM [Purchasing].[PurchaseOrderHeader] GROUP BY [VendorID] ORDER BY COUNTER01 DESC
