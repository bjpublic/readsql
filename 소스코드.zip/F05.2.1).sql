SELECT DISTINCT([Gender]) AS DC01 FROM [HumanResources].[Employee]

SELECT [Gender] FROM [HumanResources].[Employee] GROUP BY [Gender]
