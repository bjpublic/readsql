SELECT DATEPART("YY",[OrderDate]) AS YY, SUM([TotalDue]) AS Y_AMOUNT FROM [Sales].[SalesOrderHeader] GROUP BY DATEPART("YY",[OrderDate]) ORDER BY DATEPART("YY",[OrderDate])
