SELECT [BusinessEntityID],[JobTitle],DATEDIFF(YY,[BirthDate],GETDATE()) AS M_AGE FROM [HumanResources].[Employee]

SELECT [BusinessEntityID],[JobTitle],DATEDIFF(YY,[HireDate],GETDATE()) AS M_WD FROM [HumanResources].[Employee]
