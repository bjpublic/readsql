SELECT * FROM [Production].[Productcategory]

SELECT [ProductSubcategoryID], [Name] FROM [Production].[ProductSubcategory]
