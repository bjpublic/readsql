SELECT * FROM [Sales].[Store] WHERE [Name] LIKE 'BIKE%'

SELECT * FROM [Sales].[Store] WHERE [Name] LIKE '%BIKE'