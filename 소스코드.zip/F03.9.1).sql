SELECT * FROM [Sales].[Store] WHERE [SalesPersonID]=277 OR [SalesPersonID]=281 OR [SalesPersonID]=283 OR [SalesPersonID]=290

SELECT * FROM [Sales].[Store] WHERE [SalesPersonID] IN (277, 281, 283, 290)