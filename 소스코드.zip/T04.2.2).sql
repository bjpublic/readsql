SELECT [Comments], LEN([Comments]) AS LEN_R FROM [Production].[ProductReview] ORDER BY LEN([Comments]) DESC

SELECT [EmailAddress], CHARINDEX('@',[EmailAddress]) AS INDEX_R, LEFT([EmailAddress],CHARINDEX('@',[EmailAddress])-1) AS LEFT_R, RIGHT([EmailAddress],LEN([EmailAddress])-CHARINDEX('@',[EmailAddress])) AS RIGHT_R FROM [Production].[ProductReview] ORDER BY LEN([Comments]) DESC

SELECT [EmailAddress], CHARINDEX('@',[EmailAddress]) AS INDEX_R, SUBSTRING([EmailAddress],1,CHARINDEX('@',[EmailAddress])-1) AS SUBSTRING01_R, SUBSTRING([EmailAddress],CHARINDEX('@',[EmailAddress])+1,LEN([EmailAddress])) AS SUBSTRING02_R FROM [Production].[ProductReview] ORDER BY LEN([Comments]) DESC
