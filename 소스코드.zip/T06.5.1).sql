SELECT * FROM [Purchasing].[PurchaseOrderHeader]

SELECT * FROM [Purchasing].[Vendor]

SELECT [BusinessEntityID], [Name] FROM [Purchasing].[Vendor]

SELECT [VendorID], [TotalDue] FROM [Purchasing].[PurchaseOrderHeader]

SELECT [VendorID], SUM([TotalDue]) AS V_AMOUNT, COUNT([VendorID]) AS V_COUNTER FROM [Purchasing].[PurchaseOrderHeader] GROUP BY [VendorID]

SELECT * FROM (SELECT [BusinessEntityID], [Name] FROM [Purchasing].[Vendor]) AS VD, (SELECT [VendorID], SUM([TotalDue]) AS V_AMOUNT, COUNT([VendorID]) AS V_COUNTER FROM [Purchasing].[PurchaseOrderHeader] GROUP BY [VendorID]) AS V_ORDER WHERE [BusinessEntityID]=[VendorID]
