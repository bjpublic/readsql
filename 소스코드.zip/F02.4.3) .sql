UPDATE [HumanResources].[Employee] SET [JobTitle]='Marketing Specialist' WHERE [BusinessEntityID]=17

SELECT * FROM [HumanResources].[Employee] WHERE [BusinessEntityID]=17