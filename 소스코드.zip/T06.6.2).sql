UPDATE [Production].[Product] SET [ListPrice]=[ListPrice]*1.1 WHERE [ProductID] IN (SELECT TOP 5 [ProductID] FROM [Purchasing].[PurchaseOrderDetail] GROUP BY [ProductID] ORDER BY SUM([LineTotal]) DESC)

SELECT TOP 5 [ProductID] FROM [Purchasing].[PurchaseOrderDetail] GROUP BY [ProductID] ORDER BY SUM([LineTotal]) DESC

SELECT * FROM [Production].[Product] WHERE [ProductID] IN (SELECT TOP 5 [ProductID] FROM [Purchasing].[PurchaseOrderDetail] GROUP BY [ProductID] ORDER BY SUM([LineTotal]) DESC)

UPDATE [Production].[Product] SET [ListPrice]=[ListPrice]*1.1 WHERE [ProductID] IN (SELECT TOP 5 [ProductID] FROM [Purchasing].[PurchaseOrderDetail] GROUP BY [ProductID] ORDER BY SUM([LineTotal]) DESC)
