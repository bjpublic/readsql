DELETE FROM [HumanResources].[Department02]

INSERT INTO [HumanResources].[Department02] SELECT [Name],[GroupName],[ModifiedDate] FROM [HumanResources].[Department]
