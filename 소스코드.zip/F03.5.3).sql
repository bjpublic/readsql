SELECT [ProductID],[BusinessEntityID],[StandardPrice],[OnOrderQty] FROM [Purchasing].[ProductVendor]

SELECT [ProductID],[BusinessEntityID],[StandardPrice],[OnOrderQty] FROM [Purchasing].[ProductVendor] WHERE [OnOrderQty]=NULL