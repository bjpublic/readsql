SELECT DATEPART(YY, [ModifiedDate]) AS DP_YY, DATEPART(MM, [ModifiedDate]) AS DP_MM, DATEPART(DD, [ModifiedDate]) AS DP_DD, DATEPART(QQ, [ModifiedDate]) AS DP_QQ, DATEPART(WW, [ModifiedDate]) AS DP_WW, DATEPART(HH, [ModifiedDate]) AS DP_HH, DATEPART(MI, [ModifiedDate]) AS DP_MI, DATEPART(SS, [ModifiedDate]) AS DP_SS FROM [Purchasing].[PurchaseOrderDetail]

SELECT * FROM [Purchasing].[PurchaseOrderDetail] WHERE DATEPART(YY, [ModifiedDate])=2104 OR DATEPART(MM, [ModifiedDate])=10
