SELECT * FROM [Sales].[SalesOrderHeader]

SELECT * FROM [Sales].[SalesOrderDetail]


SELECT [SalesOrderID],[SalesPersonID] FROM [Sales].[SalesOrderHeader]

SELECT [SalesOrderID],[ProductID],[OrderQty],[LineTotal] FROM [Sales].[SalesOrderDetail]


SELECT * FROM (SELECT [SalesOrderID],[SalesPersonID] FROM [Sales].[SalesOrderHeader]) AS ORDER_L, (SELECT [SalesOrderID],[ProductID],[OrderQty],[LineTotal] FROM [Sales].[SalesOrderDetail]) AS ORDER_D WHERE ORDER_L.[SalesOrderID]=ORDER_D.[SalesOrderID]


SELECT [SalesPersonID], [ProductID], COUNT([OrderQty]) AS P_COUNTER, SUM([LineTotal]) AS P_AMOUNT FROM (SELECT [SalesOrderID],[SalesPersonID] FROM [Sales].[SalesOrderHeader]) AS ORDER_L, (SELECT [SalesOrderID],[ProductID],[OrderQty],[LineTotal] FROM [Sales].[SalesOrderDetail]) AS ORDER_D WHERE ORDER_L.[SalesOrderID]=ORDER_D.[SalesOrderID] GROUP BY [SalesPersonID], [ProductID] HAVING [SalesPersonID] IS NOT NULL ORDER BY [SalesPersonID]
