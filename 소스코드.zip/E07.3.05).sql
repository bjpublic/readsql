SELECT [ProductID], [4], [5], [6] FROM
(SELECT [ProductID], DATEPART(MM,[ModifiedDate]) AS MM, SUM(LineTotal) AS PM_AMOUNT FROM [Sales].[SalesOrderDetail] WHERE [ModifiedDate] BETWEEN '2014-04-01' AND '2014-06-30' 
GROUP BY [ProductID], DATEPART(MM,[ModifiedDate])) AS PM_R
PIVOT
(SUM(PM_AMOUNT) FOR [MM] IN ([4], [5], [6]) ) PIVOT_PM_R
